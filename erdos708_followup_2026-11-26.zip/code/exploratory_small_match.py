from collections import defaultdict,Counter
from math import gcd,lcm,prod
from itertools import combinations
from random import Random
import networkx as nx
from sympy import factorint

def split(a):
    arr=sorted([p**e for p,e in factorint(a).items()],reverse=True)
    x,y=1,1
    for q in arr:
        if x<=y:x*=q
        else:y*=q
    return x,y

def mixed(x):return len(factorint(x))>=2

def deficit(A,shift):
    M=max(A); I=range(shift+1,shift+M+1); n=len(A)
    ans=[]
    for a0 in A:
        hs=[h for a in A if a!=a0 for h in split(a) if mixed(h)]
        if not hs: return 0,(),None
        adj=[{b for b in I if b%h==0} for h in hs]
        allseen=set().union(*adj)
        owner={}
        def aug(i,seen):
            for b in adj[i]:
                if b in seen:continue
                seen.add(b)
                if b not in owner or aug(owner[b],seen):
                    owner[b]=i;return True
            return False
        match=sum(aug(i,set()) for i in range(len(hs)))
        if match<len(hs):
            ans.append((len(hs)-match,a0,hs,match,len(allseen)))
        else:return 0,(),None
    return min((t[0] for t in ans),default=0), A, ans

rng=Random(708)
tests=0;fail=[]
for M in range(12,101):
    for n in [min(M-1, z) for z in [4,7,12,20,40]]:
        if n>=M:continue
        for _ in range(50):
            A=tuple(sorted(set(rng.sample(range(2,M+1),n-1)+[M])))
            if len(A)!=n:continue
            shift=rng.choice([0,rng.randrange(M*M),int(__import__('math').lcm(*range(2,min(M,12))))-M//2])
            missing,a,allans=deficit(A,shift)
            tests+=1
            if missing:
                fail.append((M,n,shift,missing,A,allans))
                print('FAILED',fail[-1],flush=True)
                if len(fail)>=4:break
        if len(fail)>=4:break
    if len(fail)>=4:break
print('RESULT',tests,fail[:4],flush=True)
