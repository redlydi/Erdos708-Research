#!/usr/bin/env python3
"""Independent checks of robust indexed arithmetic progression expansion and glue theorem.
Does not prove asymptotic assertions. Deterministic seed, Python 3.10+, scipy optional.
"""
from itertools import combinations
from collections import Counter
from functools import lru_cache
from math import gcd, prod, lcm
from random import Random
from pathlib import Path
import json

SEED=7082611262
rng=Random(SEED)

@lru_cache(None)
def atoms(x):
    ans=[];d=2
    while d*d<=x:
        if x%d==0:
            q=1
            while x%d==0:x//=d;q*=d
            ans.append((d,q))
        d+=1
    if x>1:ans.append((x,x))
    return tuple(ans)

def split(a):
    blocks=[1,1]
    for _,q in sorted(atoms(a),key=lambda z:-z[1]):
        blocks[0 if blocks[0]<=blocks[1] else 1]*=q
    return blocks

def omega(x):return len(atoms(x))

def all_levels(A):
    c=Counter()
    for a in A:
        for p,q in atoms(a):
            while q>1:
                c[(p,q)]+=1
                q//=p
    return c

def covered(A,B):
    return all(sum(b%q==0 for b in B)>=need for (p,q),need in all_levels(A).items())

def trial_aps():
    seen=0;robust=0;forbidden_tests=0;max_ratio=0
    for trial in range(1400):
        m=rng.randrange(2,9)
        L=rng.choice([4,6,8,10,12,14,16,18,24])
        H=rng.randrange(max(2*L,32),max(2*L,32)+180)
        candidates=range(1,(H-1)//(L-1)+1)
        steps=[rng.choice(candidates) for _ in range(m)]
        rows=[]
        for d in steps:
            a=rng.randrange(0,H-(L-1)*d)
            rows.append(tuple(a+j*d for j in range(L)))
        kap=max(sum(t%d==0 for d in steps) for t in range(1,H+1))
        rho=L/(3*(kap*kap*m)**(1/3))
        if rho<1.00001:continue
        robust+=1
        for r in range(1,m+1):
            for S in combinations(range(m),r):
                U=set().union(*(set(rows[i]) for i in S))
                # verify the union-growth lemma for every subfamily
                assert len(U)+1e-9>=rho*r,(m,L,kap,S,len(U),rho*r)
                seen+=1
        if trial%6==0:
            candidates=set().union(*(set(z) for z in rows))
            for _ in range(4):
                R=rng.randrange(0,min(len(candidates),4*m)+1)
                forbidden=set(rng.sample(sorted(candidates),R))
                adjacency=[set(row)-forbidden for row in rows]
                owners={}
                def aug(i,visit):
                    for b in sorted(adjacency[i]):
                        if b in visit:continue
                        visit.add(b)
                        if b not in owners or aug(owners[b],visit):
                            owners[b]=i
                            return True
                    return False
                achieved=sum(aug(i,set()) for i in range(m))
                deficiency=m-achieved
                assert deficiency <=R/rho+1e-8,(m,L,kap,R,rho,deficiency)
                forbidden_tests+=1
                max_ratio=max(max_ratio,deficiency)
    return dict(valid_subfamilies=seen,robust_instances=robust,forbidden_matching_tests=forbidden_tests,max_deficiency=max_ratio)

def next_multiple(lo,d):return lo+(-lo)%d

def core_cover(A0,d,shift,M):
    # A0 must have common divisor d, cofactor support budget <=2s-1
    s=len(A0);C=[a//d for a in A0]
    assert len(set(C))==s and sum(omega(c) for c in C)<=2*s-1
    # use interval [shift+1, shift+d*max C], subset of full length M
    lo=shift+1; Q=max(C); first=next_multiple(lo,d); Jlo=first//d
    Jhi=Jlo+Q-1
    # Independent per-prime top-valuation selections; union does not lose coverage.
    chosen=set()
    lev=all_levels(C)
    for p in sorted(set(p for p,q in lev)):
        k=sum(c%p==0 for c in C)
        def valuation(v):
            z=0
            while v%p==0:
                z+=1
                v//=p
            return z
        chosen.update(sorted(range(Jlo,Jhi+1),key=valuation,reverse=True)[:k])
    assert covered([c for c in C if c>1],chosen)
    for v in range(Jlo,Jhi+1):
        if len(chosen)>=s:break
        chosen.add(v)
    F={d*v for v in chosen}
    assert len(F)<=2*s-1
    assert min(F)>=shift+1 and max(F)<=shift+M
    assert covered(A0,F)
    return F

def gluing_test():
    examples=[]
    for i in range(120):
        small=(i>=60)
        core_primes=[11,13,17,19,23] if small else [101,103,107,109,113]
        d=rng.choice([6,30] if small else [6,30,210])
        s=(5 if small else rng.randrange(2,6))
        A0=[d*p for p in core_primes[:s]]
        # 3-atom light inputs, one mixed h each; d-cores repeat s times.
        A1=[6*211,35*37] if small else [6*100003,35*100019]
        if len(set(A0+A1))<s+2:continue
        M=max(A0+A1)
        P=lcm(*([2,3,5,7,11,13,17,19,23,37,211] if small else [2,3,5,7,11,13,101,103,107,109,113,100003,100019]))
        shift=rng.choice([0,37,M*3,P-M//2])
        F0=core_cover(A0,d,shift,M)
        mixed=[];single=[]
        for a in A1:
            for h in split(a):
                if omega(h)>1:mixed.append(h)
                elif h>1:single.append(h)
        assert mixed==[6,35],mixed
        used=set(F0); assigned=[]
        for h in mixed:
            lo=next_multiple(shift+1,h)
            for b in range(lo,shift+M+1,h):
                if b not in used:
                    used.add(b);assigned.append(b);break
            else:raise AssertionError('cannot match')
        assert len(assigned)==len(mixed)
        # Patch each prime by selecting k highest-valuation unoccupied positions.
        lev=all_levels(A0+A1)
        for p in sorted(set(p for p,q in lev)):
            qlist=[q for pp,q in lev if pp==p]
            k=max(0,max(lev[(p,q)]-sum(b%q==0 for b in used) for q in qlist))
            if k:
                # Every needed p-power is 1 here; for generic cases use top valuations.
                assert all(q==p for q in qlist)
                b=next_multiple(shift+1,p)
                for _ in range(k):
                    while b in used:b+=p
                    assert b<=shift+M
                    used.add(b)
                    b+=p
        assert covered(A0+A1,used)
        assert len(used)<=2*(s+len(A1))-1
        examples.append(dict(regime=('intermediate' if small else 'large'),s=s,d=d,M=M,shift_kind=('CRT' if shift==P-M//2 else 'ordinary'),core_points=len(F0),used_points=len(used),budget=2*(s+2)-1))
    return {'cases':len(examples),'intermediate_cases':sum(z['regime']=='intermediate' for z in examples),'max_used_minus_budget':max(x['used_points']-x['budget'] for x in examples),'examples':[examples[0], examples[60]]}

def test_nonunitary_cores():
    # Cofactors need not be coprime to d or to one another.
    tested=0; examples=[]
    P=lcm(*range(2,16))
    for _ in range(1600):
        d=rng.choice([6,9,30,210])
        s=rng.randrange(2,7)
        C=rng.sample(range(1,51),s)
        if sum(omega(c) for c in C)>2*s-1:continue
        M=d*max(C)
        shift=rng.choice([0,13,P-M//2 if P>M else 0])
        B=core_cover([d*c for c in C],d,shift,M)
        assert len(B)<=2*s-1
        tested+=1
        if len(examples)<2:examples.append({'d':d,'C':C,'M':M,'cover_size':len(B)})
    return {'nonunitary_and_shared_cofactor_examples':tested,'examples':examples}

def test_dense_core_high_complexity():
    # An example outside the average <=2 prime-complexity criterion.
    C=sorted(range(1,101),key=lambda c:(-omega(c),c))[:50]
    if 100 not in C:C[-1]=100
    assert len(set(C))==50 and max(C)==100
    strength=sum(omega(c) for c in C)
    assert strength==108>2*len(C)
    d=30;M=d*max(C);A=[d*c for c in C]
    P=lcm(*range(2,20))
    checks=0
    for shift in [0,17,20000,P-1111]:
        B={b for b in range(shift+1,shift+M+1) if b%d==0}
        assert len(B)==100==2*len(A)
        assert covered(A,B)
        checks+=1
    return {'s':len(C),'Q':max(C),'cofactor_omega_sum':strength,'compression_budget':len(B),'verified_shifts':checks}

def main():
    results={'seed':SEED,'expansion':trial_aps(),'gluing':gluing_test(),'nonunitary_core':test_nonunitary_cores(),'dense_high_complexity':test_dense_core_high_complexity()}
    target=Path(__file__).with_name('robust_results.json')
    target.write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(results,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
