from random import Random
from math import lcm
from sympy import factorint
from functools import lru_cache
from collections import Counter
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import maximum_bipartite_matching
@lru_cache(None)
def split(a):
    pairs=sorted([p**e for p,e in factorint(a).items()],reverse=True)
    x=y=1
    for q in pairs:
        if x<=y:x*=q
        else:y*=q
    return (x,y)
@lru_cache(None)
def mixed(a):return len(factorint(a))>1

def deficiency(A,shift,reserve=True):
    M=max(A)
    mix=[(a,h) for a in A for h in split(a) if mixed(h)]
    if not mix:return 0,0
    m=len(mix)
    # Pick core row a0 with maximum number of mixed atoms, and remove it
    a0=max(A,key=lambda a:sum(mixed(h) for h in split(a)))
    mix=[(a,h) for a,h in mix if a!=a0]
    c=M//a0
    # use b0 nearest interval start, or center if possible
    b0=((shift//a0)+1)*a0
    indices=[]; cols=[]
    for i,(a,h) in enumerate(mix):
        start=((shift//h)+1)*h
        for b in range(start,shift+M+1,h):
            if reserve and b==b0:continue
            indices.append(i);cols.append(b-shift-1)
    if len(mix)==0:return 0,0
    x=csr_matrix(([1]*len(indices),(indices,cols)),shape=(len(mix),M))
    mat=maximum_bipartite_matching(x,perm_type='column')
    return len(mix)-sum(int(v>=0) for v in mat),len(mix)

r=Random(708111)
ps=[]
for M in (100,150,200,300,500):
    ctr=Counter();fail=[]
    lc=lcm(*range(2,19))
    for n in [M//6,M//4,M//3,M//2,M-1]:
        for mode in range(6):
            for rep in range(60):
                A=set([M])
                arr=list(range(2,M));r.shuffle(arr)
                if mode==1:arr.sort(key=lambda a:(-int(a%6==0),r.random()))
                elif mode==2:arr.sort(key=lambda a:(-int(a%30==0),r.random()))
                elif mode==3:arr.sort(key=lambda a:(-len(factorint(a)),r.random()))
                elif mode==4:arr.sort(key=lambda a:(-int(a%210==0),r.random()))
                elif mode==5:arr.sort(key=lambda a:(-len(factorint(a)),abs(a-M*.8),r.random()))
                A.update(arr[:n-1]);A=tuple(sorted(A))
                shift=r.choice([0,M*3,lc-M//2,lc*r.randrange(1,4)-M//2])
                d,m=deficiency(A,shift)
                ctr[(n,mode)]+=1
                if d:fail.append((n,mode,shift,d,m,A))
    print('M',M,'TOTAL',sum(ctr.values()),'FAILURES',len(fail),'MAXDEF',max([t[3] for t in fail],default=0),flush=True)
    if fail:
        print('FIRST',fail[0],flush=True)
