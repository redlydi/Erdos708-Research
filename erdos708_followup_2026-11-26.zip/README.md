# Erdős 708 — research continuation (2026-11-26)

A self-contained, independent research report and reproducible checks. This work **does not** prove the universal `g(n) <= (2+o(1)) n` conjecture. It establishes, at the level of written mathematical argument, a robust arithmetic-progression expansion lemma, an explicit forbidden-position Hall deficiency bound, and a quantitative heavy/light gluing theorem for structural subclasses.

## Files
- `REPORT.md` — full Russian mathematical write-up with proofs, status table, known gaps and references.
- `code/verify_robust_gluing.py` — reproducible finite tests including non-unitary cofactor overlaps and dense high-complexity cores (Python standard library).
- `verification/robust_results.json` — finite test outputs (seed `7082611262`).
- `code/exploratory_small_match.py`, `code/exploratory_greedy_matching.py` — heuristic random matching searches (requires `sympy`, `scipy`, `networkx`).
- `verification/previous_replay_stdout.txt` — replay of the previous `verify.py` script.

## Reproduce
```bash
python3 code/verify_robust_gluing.py
```
The verification program writes `robust_results.json` next to its script when executed. For a clean working directory, copy this file to `verification/` afterward. Randomized experiments are not proofs of asymptotic statements. The paper's theorems are not Lean-checked.

## Provenance
The two earlier ZIPs were read from the current conversation's attached working directory; original repository source reports are referenced by exact SHA in `REPORT.md`. No source file in the user's GitHub repository was edited.
