import Lean

namespace Dense708

-- v, A and C have common denominator 1000. F is scaled by 2·10^9.
def endpointNumerator (v : Int) : Int :=
  1000000000 + 500000 * v + 500 * v * v
    - 217 * (v - 406) * (v - 406) - 1000000 * max (v - 1000) 0

theorem endpoint_bounds :
    endpointNumerator 975 < 1951000000 ∧
    endpointNumerator 1000 < 1951000000 ∧
    endpointNumerator 1099 < 1951000000 := by decide

theorem overlap_constants :
    (6 * (500 : Int) - (1099 - 406) > 6 * 384) ∧
    (217 * (1000 + 2 * 384) ≤ 1000 * 384) ∧
    (500 : Int) - 217 > 0 := by decide

theorem dense_budget : (1951 : Int) * 41 < 2 * 2000 * 20 := by decide

-- G = F - 1/2, with the same scale as endpointNumerator.
theorem density_endpoints :
    endpointNumerator 949 - 1000000000 < 949500000 ∧
    endpointNumerator 1000 - 1000000000 < 949500000 ∧
    endpointNumerator 1093 - 1000000000 < 949500000 := by decide

def thirdNumerator (v : Int) : Int :=
  6002500000 + 3000000 * v + 3000 * v * v
    - 1302 * (v - 406) * (v - 406) - 8700000 * max (v - 1000) 0

theorem third_density_endpoints :
    thirdNumerator 786 < 11554200000 ∧
    thirdNumerator 1000 < 11554200000 ∧
    thirdNumerator 1080 < 11554200000 := by decide

theorem endpoint_cuts :
    (9747 : Int) * 9747 > 95000000 ∧
    (24950 : Int) * 1000 < 93 * 268975 ∧
    (8165 : Int) * 8165 * 3 > 2 * 100000000 ∧
    (305 : Int) * 4 * 1000 < 80 * (40000 - 3 * 8165) := by decide

-- The two bounds on F use opposite signs for the same source statistic.
theorem average_bounds (objective source c d : Int)
    (one : objective ≤ source - d)
    (two : objective ≤ c - source) : 2 * objective ≤ c - d := by omega

theorem average_bounds_49_20 (objective source c d : Int)
    (one : objective ≤ source - d)
    (two : 20 * objective ≤ c - 29 * source) :
    49 * objective ≤ c - 29 * d := by omega

def interval : List Nat := [5, 6, 7, 8]

theorem strict_product_example :
    2 * 4 ∣ (8 : Nat) ∧
    (interval.filter (fun b => b % 2 == 0)).length = 2 ∧
    (interval.filter (fun b => b % 4 == 0)).length = 1 := by decide

#print axioms endpoint_bounds
#print axioms overlap_constants
#print axioms dense_budget
#print axioms density_endpoints
#print axioms endpoint_cuts
#print axioms third_density_endpoints
#print axioms average_bounds
#print axioms average_bounds_49_20
#print axioms strict_product_example

end Dense708
