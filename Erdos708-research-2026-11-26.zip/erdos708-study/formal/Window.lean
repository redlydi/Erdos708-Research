import Lean

/-! Lean 4.8.0, core library only. An owner is the (unique) window containing
a forbidden target point. Values outside [0,r) may encode the unused suffix.
An injection of labelled cofactors in a window loses at most its load. -/
namespace IntervalTransfer

def sumBelow (f : Nat → Nat) : Nat → Nat
  | 0 => 0
  | r+1 => sumBelow f r + f r

def hits (i : Nat) : List Nat → Nat
  | [] => 0
  | j :: js => (if i = j then 1 else 0) + hits i js

theorem prefix_add (f g : Nat → Nat) (r : Nat) :
    sumBelow (fun i => f i + g i) r = sumBelow f r + sumBelow g r := by
  induction r with
  | zero => rfl
  | succ r ih => simp only [sumBelow, ih]; omega

theorem one_owner (j r : Nat) :
    sumBelow (fun i => if i = j then 1 else 0) r = (if j < r then 1 else 0) := by
  induction r with
  | zero => simp [sumBelow, Nat.not_lt_zero]
  | succ r ih => simp only [sumBelow, ih]; split <;> split <;> split <;> omega

theorem total_load (owners : List Nat) (r : Nat) :
    sumBelow (fun i => hits i owners) r ≤ owners.length := by
  induction owners with
  | nil =>
    induction r with
    | zero => decide
    | succ r ih => simpa [sumBelow, hits] using ih
  | cons j js ih =>
    change sumBelow (fun i => (if i = j then 1 else 0) + hits i js) r ≤ js.length + 1
    rw [prefix_add, one_owner]
    split <;> omega

theorem prefix_lower (f : Nat → Nat) (r k : Nat)
    (h : ∀ i, i < r → k ≤ f i) : k*r ≤ sumBelow f r := by
  induction r with
  | zero => simp [sumBelow]
  | succ r ih =>
    have hr := ih (fun i l => h i (by omega))
    have hl := h r (by omega)
    rw [Nat.mul_succ, sumBelow]
    omega

theorem sparse_window (owners : List Nat) (r : Nat) (hr : 0 < r) :
    ∃ i, i < r ∧ hits i owners ≤ owners.length / r := by
  apply Classical.byContradiction
  intro noWindow
  have every : ∀ i, i < r → owners.length / r + 1 ≤ hits i owners := by
    intro i hi
    have hn : ¬ hits i owners ≤ owners.length / r := fun hh => noWindow ⟨i, hi, hh⟩
    omega
  have lb := prefix_lower (fun i => hits i owners) r _ every
  have ub := total_load owners r
  have h := (Nat.le_div_iff_mul_le hr).2 (Nat.le_trans lb ub)
  omega

/-! A list of groups is given by its sizes and the bounds on its cofactor
values. If W * Q_i ≤ M * N_i and at most L layers suffice in each group,
aggregation does not incur another factor for the number of groups. -/
theorem total_width (q size : Nat → Nat) (r W M L : Nat)
    (localCapacity : ∀ i, i < r → W * q i ≤ M * size i) :
    W * sumBelow (fun i => q i * L) r ≤ M * sumBelow size r * L := by
  induction r with
  | zero => simp [sumBelow]
  | succ r ih =>
    have prev := ih (fun i hi => localCapacity i (by omega))
    have term := Nat.mul_le_mul_right L (localCapacity r (by omega))
    rw [sumBelow, sumBelow, Nat.mul_add, Nat.mul_add, Nat.add_mul, ← Nat.mul_assoc W]
    exact Nat.add_le_add prev term

/-! A single nested prime-power level after selecting the k remaining points
of greatest valuation. All symbols are counts at this level. -/
theorem repair_level (need used available k : Nat)
    (enough : need ≤ used + available) (deficit : need ≤ used + k) :
    need ≤ used + min k available := by
  omega

#print axioms sparse_window
#print axioms total_width
#print axioms repair_level
end IntervalTransfer
