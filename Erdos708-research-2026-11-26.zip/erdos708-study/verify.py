"""Exact rational checks, deterministic level repair, and reproducible LP experiments."""
from argparse import ArgumentParser
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations_with_replacement
from math import isqrt, log, prod
from random import Random
import json

SEED = 708205


def prime_powers(m):
    sieve = bytearray(b"\x01") * (m + 1)
    for p in range(2, isqrt(m) + 1):
        if sieve[p]:
            sieve[p * p :: p] = b"\x00" * ((m - p * p) // p + 1)
    levels = {}
    for p in range(2, m + 1):
        if sieve[p]:
            levels[p] = [p]
            while levels[p][-1] <= m // p:
                levels[p].append(levels[p][-1] * p)
    return levels


def source_counts(source, powers):
    m = max(source)
    all_levels = (q for levels in powers.values() for q in levels)
    counts = Counter()
    present = set(source)
    for q in all_levels:
        found = sum(a in present for a in range(q, m + 1, q))
        if found:
            counts[q] = found
    return counts


def level_budget(source, powers):
    n = len(source)
    counts = source_counts(source, powers)
    return n + sum(max(max(counts[q] - n // q, 0) for q in levels)
                   for levels in powers.values())


def repair(source, shift, powers):
    n, m = len(source), max(source)
    chosen = set(range(shift + 1, shift + n + 1))
    counts = source_counts(source, powers)
    for p, levels in powers.items():
        if not counts[p]:
            continue
        candidates = [b for b in range((shift // p + 1) * p, shift + m + 1, p)
                      if b not in chosen]
        depth = lambda b: sum(b % q == 0 for q in levels)
        deficit = max(counts[q] - sum(b % q == 0 for b in chosen) for q in levels)
        if deficit > 0:
            chosen.update(sorted(candidates, key=depth, reverse=True)[:deficit])
    assert len(chosen) <= level_budget(source, powers)
    assert all(sum(b % q == 0 for b in chosen) >= demand for q, demand in counts.items())
    assert prod(chosen) % prod(source) == 0
    return len(chosen)


def exact_checks():
    c, k, b = Q(384, 1000), Q(217, 1000), Q(406, 1000)
    low, cutoff, high = Q(975, 1000), Q(1951, 2000), Q(1099, 1000)
    assert Q(1, 2) - (high - b) / 6 > c and k * (1 + 2 * c) <= c
    assert 1 + 4 * (1 - cutoff) < high
    assert cutoff * Q(41, 20) < 2
    f = lambda v: Q(1, 2) + (v + v * v) / 4 - k * (v - b) ** 2 / 2 - max(v - 1, 0) / 2
    endpoints = {str(v): str(f(v)) for v in (low, Q(1), high)}
    assert max(map(Q, endpoints.values())) < cutoff
    ext_endpoints = {str(v): str(f(v) - Q(1, 2)) for v in (Q(".949"), Q(1), Q("1.093"))}
    assert max(map(Q, ext_endpoints.values())) < Q(".47475")
    assert Q(".9747") ** 2 > Q(".95")
    assert Q(".02495") / Q(".268975") < Q(".093")
    assert Q(".8165") ** 2 > Q(2, 3)
    assert (Q(".8165") - Q(".786")) / (1 - 3 * Q(".8165") / 4) < Q(".08")
    log_upper = sum((-1) ** (j + 1) * Q(1, 2) ** j / j for j in range(1, 8))
    assert log_upper < b
    lam = Q(49, 20)

    def tripled_density(v):
        return ((v + v * v + lam * lam / 3) / 2 - k * (v - b) ** 2
                - (lam - 1) * max(v - 1, 0)) / lam

    third_endpoints = {str(v): str(tripled_density(v)) for v in (Q(".786"), Q(1), Q("1.08"))}
    assert max(map(Q, third_endpoints.values())) < Q(".786")
    jensen_checks = 0
    for degree in range(7):
        for nums in combinations_with_replacement(range(9), degree):
            weights = [Q(a, 8) for a in nums]
            mean = sum(weights)
            variance = sum(p * (1 - p) for p in weights)
            bernoulli_hinge = mean - 1 + prod(1 - p for p in weights)
            gap = bernoulli_hinge - max(mean - 1, 0)
            assert 0 <= gap <= variance / 2
            jensen_checks += 1
    return {"endpoint_values": endpoints, "endpoint_values_density_19_over_40": ext_endpoints,
            "endpoint_values_density_one_third": third_endpoints, "Jensen_exact_checks": jensen_checks}


def sample_sources(rng):
    results = []
    for n, m in [(160, 320), (160, 656), (160, 870), (320, 640),
                 (320, 1312), (320, 2190), (1000, 2050), (1000, 10000)]:
        powers = prime_powers(m)
        values = []
        for trial in range(60):
            source = sorted([*rng.sample(range(2, m), n - 1), m])
            values.append(level_budget(source, powers))
            if trial < 3 and m <= 1312:
                repair(source, rng.randrange(10**50), powers)
        results.append({"n": n, "M": m, "samples": len(values), "min": min(values),
                        "mean": sum(values) / len(values), "max": max(values),
                        "main_term": n * (1 + log(log(m) / log(n)))})
    return results


def crt_phase(m, powers, rand, mode):
    x, modulus = 0, 1
    for levels in powers.values():
        q = levels[-1]
        if mode == "aligned":
            residue = -(m // 2)
        elif mode == "random":
            residue = rand.randrange(q)
        else:
            raise ValueError(mode)
        x += modulus * ((residue - x) * pow(modulus, -1, q) % q)
        modulus *= q
    return x


def lp_sweep(rng):
    import numpy as np
    from scipy.optimize import linprog, milp, Bounds, LinearConstraint
    from scipy.sparse import csr_matrix, eye, hstack

    results = []
    for m, ratios in [(48, [2.05, 3.0, 5.0]), (100, [2.05, 3.0, 5.0]),
                      (240, [2.05, 3.0, 5.0]), (600, [2.05, 3.0, 5.0])]:
        powers = prime_powers(m)

        def valuations(x):
            return np.int64([[sum((x + i) % q == 0 for q in levels)
                              for i in range(1, m + 1)] for levels in powers.values()])

        origin = valuations(0)
        for mode in ("initial", "random", "aligned"):
            x = 0 if mode == "initial" else crt_phase(m, powers, rng, mode)
            target = valuations(x)
            p_count = len(powers)
            constraints = hstack([csr_matrix(target.T), -eye(m)], format="csr")
            for ratio in ratios:
                n = round(m / ratio)
                random_ids = rng.sample(range(1, m - 1), n - 1)
                smallest_even = sorted(range(1, m - 1),
                                       key=lambda i: (-(i % 2), i))[:n - 1]
                heavy = np.argsort(-origin[:, 1:m-1].sum(axis=0), kind="stable")[:n - 1] + 1
                best = None
                evaluations = 0
                for seed in (random_ids, smallest_even, heavy):
                    indices = tuple(sorted([*map(int, seed), m - 1]))
                    seen = set()
                    for _ in range(8):
                        if indices in seen:
                            break
                        seen.add(indices)
                        demand = origin[:, indices].sum(axis=1)
                        lp = linprog(np.r_[-demand, np.ones(m)], A_ub=constraints,
                                     b_ub=np.ones(m), bounds=[(0, 1)] * p_count + [(0, None)] * m,
                                     method="highs")
                        assert lp.success, lp.message
                        evaluations += 1
                        if best is None or -lp.fun > best[0]:
                            best = (-float(lp.fun), indices, demand)
                        scores = lp.x[:p_count] @ origin[:, 1:m-1]
                        new = np.argsort(-scores, kind="stable")[:n - 1] + 1
                        indices = tuple(sorted([*map(int, new), m - 1]))
                optimum, ids, demand = best
                primal = linprog(np.ones(m), A_ub=-target, b_ub=-demand, bounds=(0, 1),
                                 method="highs")
                assert primal.success and abs(primal.fun - optimum) < 1e-6
                assert (target[:, primal.x > 1e-8].sum(axis=1) >= demand).all()
                chosen_lp = int(sum(primal.x > 1e-8))
                product_cover = None
                if m <= 100:
                    ip = milp(np.ones(m), integrality=np.ones(m), bounds=Bounds(0, 1),
                              constraints=LinearConstraint(target, demand, np.inf),
                              options={"time_limit": 4})
                    if ip.success:
                        assert (target[:, ip.x > .5].sum(axis=1) >= demand).all()
                        product_cover = int(sum(ip.x > .5))
                results.append({"M": m, "n": n, "ratio": ratio, "phase": mode,
                                "phase_residue": str(x), "LP": round(optimum, 8),
                                "LP_over_n": round(optimum / n, 8),
                                "rounded_primal_witness": chosen_lp, "MILP": product_cover,
                                "A": [i + 1 for i in ids], "evaluations": evaluations})
    return results


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--lp", action="store_true", help="also run SciPy LP and MILP")
    args = parser.parse_args()
    rng = Random(SEED)
    result = {"seed": SEED, "exact": exact_checks(), "source_samples": sample_sources(rng)}
    if args.lp:
        result["capped_lp_experiments"] = lp_sweep(rng)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
