#!/usr/bin/env python3
"""Independent, standard-library audit tests for Erdős #708.

Does not prove any asymptotic theorem; exact finite identities and invariants only.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
from math import gcd, lcm, prod
from random import Random
import json


def prime_atoms(a):
    out = []
    d = 2
    while d * d <= a:
        if a % d == 0:
            q = 1
            while a % d == 0:
                a //= d
                q *= d
            out.append((d, q))
        d += 1
    if a > 1:
        out.append((a, a))
    return out


def is_unitary(h, a):
    return h > 0 and a % h == 0 and gcd(h, a // h) == 1


def partition(a):
    b = [1, 1]
    for p, q in sorted(prime_atoms(a), key=lambda x: -x[1]):
        b[0 if b[0] <= b[1] else 1] *= q
    assert b[0] * b[1] == a and gcd(*b) == 1
    return b


def unitary_divisors(a):
    ds = [1]
    for p, q in prime_atoms(a):
        ds += [z * q for z in ds]
    return ds


def requirements(rows):
    count = Counter()
    for a in rows:
        for p, q in prime_atoms(a):
            v = p
            while v <= q:
                count[(p, v)] += 1
                v *= p
    return count


def deficits(req, points):
    return {p: max(0, max((target - sum(b % q == 0 for b in points)
                         for (prime, q), target in req.items() if prime == p), default=0))
            for p in {p for p, _ in req}}


def vcap(b, p, M):
    if b == 0:
        return M.bit_length() + 1
    j = 0
    while b % p == 0:
        j += 1
        b //= p
    return j


def exact_list(I, h):
    return [b for b in I if is_unitary(h, b)]


def group_tasks(rows, W):
    M = max(rows)
    original = {a: partition(a) for a in rows}
    D = {d for a, blocks in original.items() for h in blocks
         if len(prime_atoms(h)) >= 2 for d in unitary_divisors(h) if d > 1}
    alive = set(rows)
    out = []  # (label, original row, type)
    group_sizes = []
    while True:
        qualifying = [(d, [a for a in sorted(alive) if is_unitary(d, a)])
                      for d in sorted(D)]
        qualifying = [(d, group) for d, group in qualifying if d * len(group) >= W]
        if not qualifying:
            break
        d, group = qualifying[0]
        group_sizes.append((d, len(group)))
        for a in group:
            out.extend([(d, a, 'main'), (a // d, a, 'extra')])
        alive.difference_update(group)
    for a in sorted(alive):
        out.extend((h, a, 'final') for h in original[a])
    assert all(a in rows and is_unitary(h, a) for h, a, _ in out if h > 1)
    assert all(len([h for h, aa, _ in out if aa == a and h > 1]) <= 2 for a in rows)
    assert sum(Fraction(1, d) for d, N in group_sizes) <= Fraction(len(rows), 1) / W
    for h, a, typ in out:
        if h <= 1:
            continue
        if typ != 'extra':
            # This also checks the inherited unitary-divisor inequality.
            for _, q in prime_atoms(h):
                assert h * h <= M * q or len(prime_atoms(h)) == 1 and typ == 'final'
    return [(h, a, typ) for h, a, typ in out if h > 1], group_sizes


def graph_surplus(hs):
    s = len(hs)
    mult = Counter(p for h in hs for p, q in prime_atoms(h))
    return sum(k-1 for k in mult.values()) - (s-1)


def audit_one(rows, shift, W, rng):
    n, M = len(rows), max(rows)
    I = list(range(shift+1, shift+M+1))
    tasks, groups = group_tasks(rows, W)
    assert len(tasks) <= 2*n
    # Audit the *deterministic* gcd-sum bound from section 4, counting
    # occurrences rather than only distinct label values.
    mix = [(h, a, typ) for h, a, typ in tasks if len(prime_atoms(h)) >= 2]
    E = sum(gcd(h, k) for (h, a, typ), (k, aa, tp) in combinations(mix, 2)
            if h != k and gcd(h, k) > 1 and
            is_unitary(gcd(h, k), h) and is_unitary(gcd(h, k), k))
    divisor_bound = max((sum(j <= h and h % j == 0 for j in range(1, h+1))
                         for h, a, typ in mix), default=1)
    crude_E_bound = len(tasks) * divisor_bound * (2 * W + Fraction(M * n, W))
    assert E <= crude_E_bound, (rows, W, E, crude_E_bound)
    by_type = defaultdict(list)
    singleton = []
    for h, a, typ in tasks:
        if len(prime_atoms(h)) == 1:
            singleton.append(h)
        else:
            by_type[h].append((a, typ))
    placed = defaultdict(list)
    leftover = singleton[:]
    overflow = 0
    for h, occurrences in by_type.items():
        V = exact_list(I, h)
        standard = sum(is_unitary(h, x) for x in range(1, M+1))
        assert len(occurrences) <= standard
        assert abs(len(V) - standard) <= (1 << len(prime_atoms(h)))
        short = max(0, len(occurrences)-len(V))
        assert short <= (1 << len(prime_atoms(h)))
        overflow += short
        leftover.extend([h] * short)
        for b in rng.sample(V, min(len(V), len(occurrences))):
            placed[b].append(h)
    # General 'graph surplus' inequality, before resolving any collisions.
    rawF = set(placed)
    raw_def = deficits(requirements(rows), rawF)
    raw_cost_bound = len(tasks) + sum(len(prime_atoms(h))-1 for h in leftover) + sum(graph_surplus(hs) for hs in placed.values())
    assert len(rawF) + sum(raw_def.values()) <= raw_cost_bound
    # Remove *all* endpoints of non-coprime collisions to simulate the proof.
    F = set()
    removed = []
    collision_pairs = 0
    for b, hs in placed.items():
        bad = {i for i in range(len(hs)) if any(i != j and gcd(hs[i], hs[j]) > 1 for j in range(len(hs)))}
        collision_pairs += sum(gcd(hs[i], hs[j]) > 1 for i in range(len(hs)) for j in range(i+1, len(hs)))
        removed.extend(hs[i] for i in bad)
        if len(bad) != len(hs):
            F.add(b)
    leftover += removed
    assert len(removed) <= 2 * collision_pairs
    req = requirements(rows)
    lack = deficits(req, F)
    for p, count in lack.items():
        assert count <= sum(p in {z for z, _ in prime_atoms(h)} for h in leftover)
    budget = len(F) + sum(lack.values())
    assert budget <= len(tasks) + sum(len(prime_atoms(h)) - 1 for h in leftover)
    # Construct the repair by descending p-adic valuations, without reuse.
    for p, k in lack.items():
        F.update(sorted(set(I) - F, key=lambda b: vcap(b,p,M), reverse=True)[:k])
    assert not any(deficits(req, F).values())
    assert len(F) <= budget
    return {'groups':len(groups),'overflow':overflow,'pair_conflicts':collision_pairs,
            'gcd_sum_E':E, 'repair_budget':budget,'size_after_repair':len(F),'raw_graph_surplus':sum(graph_surplus(hs) for hs in placed.values())}


def brute_identity(rows, shift):
    M = max(rows)
    I = list(range(shift+1, shift+M+1))
    req = requirements(rows)
    optimum = M + 1
    formula = M + 1
    for mask in range(1 << M):
        F = [b for j,b in enumerate(I) if mask >> j & 1]
        lack = deficits(req, F)
        formula = min(formula, len(F)+sum(lack.values()))
        if not any(lack.values()):
            optimum = min(optimum, len(F))
    assert optimum == formula
    return optimum


def run():
    rng = Random(708261126)
    results = {'test_cases':0,'group_extractions':0,'overflow_tasks':0,
               'collision_pairs':0,'total_gcd_sum_E':0,'brute_minimum_checks':0,'large_shift_tests':0,
               'max_abs_graph_surplus':0}
    for M in (18, 30, 45, 70, 105, 150):
        crt = lcm(*range(1, M+1))
        for s in (-M, 0, M+17, crt-M//2, 10*crt+7):
            for _ in range(35):
                n = rng.randrange(3, min(M, 24))
                rows = sorted(rng.sample(range(2, M), n-1)+[M])
                W = rng.choice([M//3, M, M*2, M*8, M**2])
                c = audit_one(rows, s, W, rng)
                results['test_cases'] += 1
                results['group_extractions'] += c['groups']
                results['overflow_tasks'] += c['overflow']
                results['collision_pairs'] += c['pair_conflicts']
                results['total_gcd_sum_E'] += c['gcd_sum_E']
                results['max_abs_graph_surplus'] = max(results['max_abs_graph_surplus'], abs(c['raw_graph_surplus']))
                if abs(s)>M*100:
                    results['large_shift_tests'] += 1
    for M in range(5, 11):
        for _ in range(14):
            n = rng.randrange(2, min(M, 5))
            rows = sorted(rng.sample(range(2, M), n-1)+[M])
            brute_identity(rows, rng.choice([0, M+3, -M//2]))
            results['brute_minimum_checks'] += 1
    # A three-label cycle has a +1 repair overhead in the graph budget.
    assert graph_surplus([6,10,15]) == 1
    assert graph_surplus([6,10]) == 0
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == '__main__':
    run()
