# Erdős–Surányi #708: independent audit and a near-critical extension

**Date:** 2026-11-26. **Scope:** mathematical audit of the *written proof* in `redlydi/Erdos708-Research`, especially `reports/erdos708-power-level-cover (1).md`, plus independent finite Python experiments and a derived quantitative refinement. **Not a claim of peer review, Lean certification, or solution of #708.**

## 0. Sources and fixed snapshot

- Main repository: https://github.com/redlydi/Erdos708-Research ; inspected default-branch commit `c7321ee76d24266327cfb37ed4e76162a6e7596e` (2026-11-25); principal report blob `805dcf5401528cdfe7c319ed1142a2c944df0ce7` (2026-11-25 report).
- Related repository: https://github.com/DenisUkranian/erdos-708-research ; read `README.md`, `STATUS.md`, and `research/asymptotic_2026_11_25/CLAIM_LEDGER.md`. It explicitly leaves the global asymptotic conjecture open and records conditional rather than universal results.
- External context: https://hexagonmath.org/2611.00694v1 (Tripodo, November 2026) reports exact finite cases `g(4)=5`, `g(5)=6`, with a stated Lean formalization; that is *not* Lean verification of the present asymptotic claim. Other cited results were not exhaustively audited.
- Additional reports skimmed for dependence and scope: `reports/erdos708-density-and-shifts(2).md`, `reports/erdos708-interval-transport (1).md` (partially), and the main `README.md`. No general validation of these separate claims is asserted.

## 1. Definitions and why the goal is stronger than product divisibility

For `A` of `n` distinct integers in `[2,M]`, `M=max A`, and an interval `I` of `M` consecutive integers, put `C_X(q)=#{x in X:q|x}` and

`H(A,I)=min{|B|:B subset I, C_B(p^j)>=C_A(p^j) for all prime powers p^j<=M}`.

Let `tau(A,I)` minimize `|B|` subject to `prod(A)|prod(B)`. Then `tau<=H`; conversely product divisibility need not satisfy each *count* of prime-power levels. Thus the principal claim is a *stronger* covering result, and does not settle the universal `g(n)<=(2+o(1))n` without removing the restriction on `M`.

The main report claims, for every fixed `eps>0`, some `c(eps)>0` with `H(A,I)<=2n+O_eps(n^(1-c))` for `M>=n^(3/2+eps)`, uniformly in `A` and *all interval shifts*.

## 2. Line-by-line audit of the critical proof chain

### 2.1. Deficit identity (§1) — independently justified

For any `F subset I` and a prime `p`, define `k_p=max_j(C_A(p^j)-C_F(p^j))_+`. Among `I\F`, take the `k_p` largest p-adic valuations (or all available; feasibility is ensured by `C_I(p^j)>=C_A(p^j)`). The chosen points raise every deficient level to its target because for each `j` the set of available multiples of `p^j` is nested and has size at least `C_A(p^j)-C_F(p^j)`. Taking the *union* of choices for all primes cannot lower counts. Hence

`H(A,I)=min_{F subset I} (|F|+sum_p k_p)`.

The reverse inequality follows by taking `F` equal to an optimal cover. This argument also handles zero in the interval: `0` is divisible by every positive prime power, and the valuation-based selection can rank it first. **Audit status: complete elementary derivation, tested by exhaustive search.**

### 2.2. Two-block unitary splitting (§2) — independently justified

Decompose each `a` into prime-power *atoms* `p^v_p(a)`; sort atoms in decreasing numerical value, insert the next atom into the currently smaller of two blocks. If `q_0` was the last atom inserted in a block `h`, its previous value was `h/q_0`, no larger than the other block, so `a>=h^2/q_0` and `h^2<=a q_0<=M q` for every atom `q` of `h`. If `h` contains at least two atoms, `q_0<=sqrt(h)` implies `h<=M^(2/3)`. Taking a unitary divisor of this block preserves `h^2<=Mq` for its retained atoms. **Audit status: elementary proof checked; tested computationally.**

This also proves the separately claimed elementary large-`M` case `M>=(2n-1)^3 => H<=2n-1`: assign one multiple to a full source modulus and assign distinct points to remaining mixed blocks using at least `floor(M/M^(2/3))>=2n-1` multiples each; repair the deferred single-atom tasks, costing at most the initial `2n-1` task count. This proof does not rely on randomness.

### 2.3. Minimal-threshold extraction and gcd budget (§§3–4) — independently checked

Let `D` be all nontrivial unitary divisors of original *mixed* blocks; `D` is downward unitary closed. For `W>0`, while some `d in D` satisfies `d r(d)>=W` among remaining sources (`r(d)=#{a remaining:d||a}`), extract the *numerically smallest* qualifying `d`, remove all such rows, and label each by `d` and `a/d`; final rows keep the initial two blocks.

Nonoverlapping extracted groups of sizes `N_d` imply `sum_extracted 1/d <= n/W` and each supplementary label `m=a/d <= M/d<= Mn/W`. Crucially, distinct rows in one group give distinct `m`. Every placed label is at most `L=max(M^(2/3),Mn/W)`.

For *compatible* labels `h,k` (same valuation on shared primes), their gcd `t` is unitary in each. Let `E` sum `gcd(h,k)` over unordered pairs of **occurrences** of *different values*, `gcd>1`, compatible. Split:

1. If at least one label is supplementary, for each fixed occurrence `z`, distinct supplementary labels of group `d` satisfy `sum_m gcd(z,m) <= sum_{t|z} t floor(M/(dt)) <= tau_0(z) M/d`. Summing groups costs at most `tau_0(z) Mn/W`.
2. Otherwise orient a pair by the earlier extraction step; final labels come last. For an earlier main label `d`, `t=gcd(d,k)` is a **proper** unitary divisor of `d`, since if `t=d`, the later row would already have been removed at extraction of `d`. The minimality rule gives `t r(t)<W` *at that earlier extraction step*. Later rows carry at most two labels each. Therefore the sum at each `t` is `<2W`. For final-final pairs the same bound follows from the stopping condition. There are at most `tau_0(d)` possibilities for `t`.

With `D_M=max_{1<=u<=M} tau_0(u)` and at most `2n` occurrences, this yields the explicit safe bound

`E <= 2n D_M (2W+Mn/W)`.

No ordinary gcd in place of *unitary* gcd is legitimate: compatibility and the minimal selection order are indispensable. This argument makes no claim that the individual pairs are independent. **Audit status: complete algebraic reconstruction; tested against explicitly enumerated occurrence pairs.**

### 2.4. Exact-multiple lists (§5) — independently checked

Define `V_h={b in I:h|b and gcd(h,b/h)=1}`. Incompatible values cannot share a point of their lists. For any label `h>1`, its occurrence count `mu(h)` is bounded by the count of `h||a` in `[1,M]`: each source has at most one unitary block labeled `h`. Inclusion–exclusion gives

`|V_h| = (M/h) prod_{p|h}(1-1/p) + O(2^omega(h))`, `mu(h)-|V_h| <= 2^omega(h)`.

**Important distinction:** equal-type occurrences must be injected into `V_h` *without replacement*. Choices for different types may be made independently. For `h!=k`, the pairwise coincidence probability is exactly `|V_h intersect V_k|/(|V_h||V_k|)`, with no claim that all pairwise collision events are independent. The usual first-moment bound then follows from `|V_h intersect V_k|<=M/lcm(h,k)+1` and the gcd sum `E`. No problem with arbitrary shifts is hidden in this bound: the `+1` is retained. The selection remains valid even when `I` includes zero: `0` is excluded from all `V_h`, `h>1`, because `gcd(h,0)=h`.

### 2.5. Final repairs and error exponents (§6) — independently checked

After dropping the shortage occurrences and both endpoints of every remaining incompatible-prime collision, surviving labels at each point have disjoint prime supports. Every source p-power atom lies in precisely one original unitary block. Therefore each missing `p^j`-level is charged to an unplaced label containing `p`. The deficit identity repairs all levels with at most `sum_{unplaced h} omega(h)` extra positions. The initial number of nontrivial labels is at most `2n`; accounting `omega(h)-1` for dropped mixed labels proves the claimed budget.

The report's exponents are consistent: with `e=min(eps,1/4)`, `delta=e/20`, `W=M^(1-delta)`, `L=max(M^(2/3), n M^delta)`, and `n^(3/2+eps)<=M<(2n-1)^3`, the ratios `W/M`, `n/W` and `n(L/M)^2` all decay by a power of `n`; multiplicative divisor-function losses `M^o(1)` and logarithmic repair losses can be absorbed in `n^(-c)` for some fixed `c>0`. **Audit status: complete check at the level of a written proof; no Lean verification.**

## 3. New quantitative extension: a shrinking exponent gap

**Derived theorem (written proof; independently computed constants not optimized).** Assume `n` is large, `n^(3/2)<=M<(2n-1)^3`, and put `f=M/n^(3/2)>=1`, `D_M=max_{u<=M}tau_0(u)`. Then an absolute constant `C` exists such that, uniformly over `A` and all shifts,

`H(A,I) <= 2n + C n (log M) D_M^3 f^(-1/3)`.

**Proof.** Set `W=M^(2/3) sqrt(n)` and `L=M^(2/3)`. Indeed `Mn/W=sqrt(n)M^(1/3)<=M^(2/3)`. For all mixed `h<=L`, `2^omega(h)<=D_M`, `prod_{p|h}(1-1/p)>=1/D_M`, and hence for large `M`:

`|V_h|>=M/(hD_M)-D_M>=M/(2hD_M)`,

because `M^(1/3)>=2D_M^2` eventually. It follows that the number of skipped occurrences from overfull lists is at most `4nD_M^2 M^(-1/3)`. For compatible distinct values, independence between *different-type injections* implies

`P(h,k) <= 4D_M^2 (gcd(h,k)/M + hk/M^2)`.

By the deterministic `E` bound and at most `2n` labels, the expected number of collision pairs is at most

`8nD_M^3 (2W/M+n/W) + 8n^2 D_M^2 L^2/M^2`.

Drop all endpoints of those pairs; a realization with no more than the expected number of pairs exists. Each dropped mixed label requires at most `omega(h)<=log_2 M` repaired prime-level slots. Thus the excess over `2n` is bounded by an absolute multiple of

`n (log M) [D_M^2 M^(-1/3) + D_M^3(W/M+n/W) + n D_M^2 L^2/M^2]`.

Now `W/M=f^(-1/3)`, `n/W=n^(-1/2) f^(-2/3)`, and `n L^2/M^2=f^(-2/3)`. Each bracketed term is `O(D_M^3 f^(-1/3))`, proving the claim. The case `M>=(2n-1)^3` already has `H<=2n-1` by §2.2. QED (written).

**Corollary.** In the regime `M>=n^(3/2) exp(omega(log n/loglog n))`, with the growth interpreted uniformly along any sequence `n->infinity`, one has `H(A,I)<=(2+o(1))n` for arbitrary shifts. Indeed `D_M=exp(O(log M/loglog M))`; within `M<(2n-1)^3`, `log M=Theta(log n)`, so `f^(-1/3)` beats the displayed factor. This is a *subpolynomial enlargement of the already treated large-M regime*, **not** a proof at `M=Theta(n^(3/2))`, still less at `M=Theta(n)`.

A more precise sufficient condition from the displayed theorem is `f / [(log M)^3 D_M^9] -> infinity`.

## 4. General collision-graph repair lemma (deterministic)

**Lemma (written proof, no random construction needed).** Suppose every source is split into at most two pairwise coprime unitary blocks, forming `T<=2n` nontrivial tasks. Some tasks are placed at positions divisible by their labels (several labels may share one point); let `U` denote unplaced tasks. Let `F` be the set of occupied points, and for each occupied `b`, let `s_b` be its number of label occurrences, and `m_p(b)` the number of those labels divisible by `p`. Define

`R_b = sum_p (m_p(b)-1)_+ - (s_b-1)`.

Then

`H(A,I) <= T + sum_{h in U}(omega(h)-1) + sum_{b in F} R_b`.

**Proof.** Each source demand at a p-power level is represented in exactly one of its blocks. A placed block's requirement is met at its assigned point, except that up to `m_p(b)-1` duplicates of the same prime may be lost at an occupied point. Hence the maximal p-level deficit is at most `#{h in U:p|h}+sum_{b in F}(m_p(b)-1)_+`. Apply the §1 deficit identity and sum over p. Because `T=|U|+sum_b s_b`, the claimed formula follows by rearrangement.

For the bipartite incidence graph of labels and prime divisors at `b` (including one vertex per *occurrence*), `R_b=beta_b-c_b+1` where `beta_b` is the cycle rank and `c_b` the number of components. Thus acyclic connected clusters cost no *extra* positions in this upper-bound accounting, whereas cycles can impose an overhead. For example, `[6,10]` at point `30` gives `R=0`; `[6,10,15]` at `30` gives `R=1`. This is a structural reason to study **incidence cycles**, not merely count all intersecting label pairs, when `M` is below the present first-moment threshold. It does *not* establish that total positive `R_b=o(n)` can always be achieved.

## 5. Reproducible verification and exact findings

Code: `code/erdos708_audit_2026_11_26.py`. Run `python3 code/erdos708_audit_2026_11_26.py`, or the standalone downloadable copy. Python 3 standard library only; seed `708261126`.

Recorded Python output:

```
{
  "brute_minimum_checks": 84,
  "collision_pairs": 28,
  "group_extractions": 58,
  "large_shift_tests": 420,
  "max_abs_graph_surplus": 1,
  "overflow_tasks": 2,
  "test_cases": 1050,
  "total_gcd_sum_E": 1250
}
```

Each generated test uses distinct source moduli, includes `max(A)=M`, independently recomputes unitary groups, checks extraction-group reciprocal bound, checks the unnormalized gcd sum on **occurrences**, the inclusion–exclusion shortage allowance, the deterministic graph repair budget, and the final full set of prime-power level inequalities after greedy repair. Shifts include negative values, ordinary positive values and multiples of `lcm(1,...,M)` far larger than M. There are 84 separately exhaustive *mask enumeration* checks of the §1 minimum identity for `5<=M<=10`. These runs are finite checks, **not** evidence of asymptotic uniformity.

A separate Wolfram Language evaluation checked unitary exact-list counts and intersections for `(h,k,M)=(6,10,40)`, with starts `1,38,211,2311`; the respective `(|V_6|,|V_10|,|V_6 intersect V_10|)` values were `(2,2,1)`, `(2,1,0)`, `(2,1,0)`, `(2,1,0)`. This is a local cross-check, not an independent formal proof.

Lean/lake are **not installed** in the execution environment used for this audit. No `.lean` certification is claimed.

## 6. Failure modes sought and remaining uncertainties

- **Same-label self-collisions:** addressed by random *injection* without replacement, not IID positions. Confirmed in §5.
- **Incomplete p-adic powers:** addressed by atomic `p^e` unitary blocks and level-by-level repair. Confirmed in §§2,6.
- **Conflict sum multiplicities:** occurrence-wise accounting is needed; distinct supplementary labels inside a group and minimum `d` extraction are essential. Re-derived in §§3–4.
- **Unbounded target shift:** local progressions can have one unexpected common point when LCM>M. The `+1` term is retained; dropping it would be unjustified. Confirmed in §5.
- **Overfull exact lists:** `mu(h)-|V_h|<=2^omega(h)` holds because source rows are distinct and the source and target intervals have the *same* length. Confirmed.
- **Dependence among collision events:** first-moment method only uses pairwise probabilities; event independence is unnecessary. Confirmed.

**What this audit does *not* provide:** a formal proof in Lean, a referee-level certainty claim, a complete replay of the secondary repository's extensive finite-case certificates, a proof of the separate dense/polynomial-shift papers, or a full survey of possible prior results. No counterexample to the stated large-M theorem was found in the examined arguments and finite tests, but lack of a counterexample is not verification.

## 7. Most promising continuation

The main obstacle is now more specific: below the `n^(3/2+o(1))` threshold the crude `+1` when `lcm(h,k)>M` is too expensive. The report's §7 shows two compatible mixed/main labels with a shared atom always have `lcm<=M`; hence genuinely difficult large-LCM pairs necessarily include a supplementary label. Candidate work: keep these labels grouped, use a *cycle-rank* estimate for the actual incidence graph after choosing positions, and amortize single-point collisions against saved positions. Any such claim must control multi-label cycles and the costs of deleted labels, without assuming independent collision indicators. The secondary repository's weighted capped-valuation / Hall reserve components might complement this strategy, but the ledger correctly marks its general mixed-support surplus bound as unproved.

### Status ledger

| Statement | Status as of this audit |
|---|---|
| `H= min_F(|F|+sum_p max_j deficit_+)` | Independently proved here; exhaustive finite checks |
| Unitary two-bin inequality and `M>=(2n-1)^3` case | Independently justified here; finite invariant tests |
| Gcd-sum estimate and exact-list injection bounds | Independently reconstructed here; finite tests; no Lean |
| Original `M>=n^(3/2+eps)` result | Written proof passes this targeted audit; **not externally certified** |
| `H<=2n+O(n log M D_M^3 f^(-1/3))` for `f=M/n^(3/2)>=1` | Derived written proof here from audited ingredients |
| Deterministic collision-graph lemma | Written elementary proof here; finite tests |
| `g(n)<=(2+o(1))n` without restriction on M | **Open** |
| Arbitrary `M=Theta(n^(3/2))` or `M=Theta(n)` | **Open by these methods** |

**All original research files remain unchanged in this audit.**
