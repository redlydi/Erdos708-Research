#!/usr/bin/env python3
"""Independent exact and randomized tests for Erdős problem #708, 2026-11-26.
Run: python3 verify.py . Python 3.10+ and scipy (optional for MILP).
No asymptotic result is inferred from these finite tests.
"""
from collections import Counter
from itertools import combinations
from math import gcd, prod
from random import Random
import json
from pathlib import Path

SEED = 708_261126

def prime_power_levels(xs):
    out = Counter()
    for a in xs:
        val = a
        p = 2
        while p * p <= val:
            if val % p == 0:
                q = 1
                while val % p == 0:
                    val //= p
                    q *= p
                out[(p,q)] += 1
            p += 1
        if val > 1:
            out[(val,val)] += 1
    # expand aggregate full-power atoms into all prime-power levels
    levels=Counter()
    for (p,q), multiplicity in out.items():
        while q > 1:
            levels[(p,q)] += multiplicity
            q //= p
    return levels

def covers(A,B):
    return all(sum(b%q==0 for b in B)>=need for (_,q),need in prime_power_levels(A).items())

def graph_surplus(labels):
    # labels are integers, each with a nonempty support of distinct prime factors
    def primes(a):
        s=set();p=2
        while p*p<=a:
            if a%p==0:
                s.add(p)
                while a%p==0:a//=p
            p+=1
        if a>1:s.add(a)
        return s
    counts=Counter(p for h in labels for p in primes(h))
    s=len(labels)
    return sum(max(0,m-1) for m in counts.values())-(s-1)

def exact_list(h,I):
    return [b for b in I if b%h==0 and gcd(h,b//h)==1]

def pair_product_family(primes,verify_lists=True):
    k=len(primes)
    assert k>=3 and len(set(primes))==k
    A=[p*q for p,q in combinations(primes,2)]
    n=len(A)
    M=max(A)
    b0=prod(primes)
    half=M//2
    I=range(b0-half,b0-half+M)
    assert min(A)>half
    assert half<min(primes)**2
    if verify_lists:
        for h in A:
            assert exact_list(h,I)==[b0], (h,exact_list(h,I))
    assert graph_surplus(A)==(k-1)*(k-2)//2
    # Each off-centre position contains at most one distinguished prime.
    for b in I:
        if b!=b0:
            assert sum(b%p==0 for p in primes)<=1
    B={b0}
    for p in primes:
        options=(b for b in I if b!=b0 and b%p==0)
        for i in range(k-2):
            B.add(next(options))
    assert len(B)==1+k*(k-2)
    assert covers(A,B)
    # Matching lower bound follows exactly from the off-centre property.
    return dict(k=k,n=n,M=M,b0=b0,forced_exact_lists=len(A),graph_surplus=graph_surplus(A),H_exact=len(B),two_n=2*n)

def forced_common_core_family(d, primes):
    k=len(primes)
    assert d>1 and all(gcd(d,p)==1 for p in primes)
    A=[d*p for p in primes]
    M=max(A);b0=d*prod(primes)
    I=range(b0-M//2,b0-M//2+M)
    assert min(A)>M//2
    for h in A:
        assert exact_list(h,I)==[b0]
    R=graph_surplus(A)
    assert R==(len(set(t for t in range(2,d+1) if d%t==0 and all(t%j for j in range(2,int(t**0.5)+1))))-1)*(k-1)
    shift=I.start-1
    check=common_core_construct(d,list(primes),shift)
    assert check['H_exact']==k
    return {'d':d,'n':k,'M':M,'b0':b0,'forced_exact_lists':k,'graph_surplus':R,'rigid_graph_upper':k+R,'H_exact':k}

def common_core_construct(d,C,shift):
    # C distinct, pairwise coprime, and coprime to d
    Q=max(C);M=d*Q
    assert d>1 and len(set(C))==len(C)
    assert all(gcd(d,c)==1 for c in C)
    assert all(gcd(a,b)==1 for a,b in combinations(C,2))
    I=range(shift+1,shift+1+M)
    K=[b//d for b in I if b%d==0]
    assert len(K)==Q and K==list(range(K[0],K[0]+Q))
    chosen=set()
    for c in C:
        chosen.add(next(v for v in K if v%c==0))
    for v in K:
        if len(chosen)==len(C):break
        chosen.add(v)
    assert len(chosen)==len(C)
    B={d*v for v in chosen}
    A=[d*c for c in C]
    assert covers(A,B)
    assert all(b in I for b in B)
    return dict(d=d,C=list(C),M=M,n=len(C),shift=shift,H_exact=len(C))

def stable_core_construct(d,C,good_indices,shift):
    """Construct an n+sum_bad omega(c) cover for arbitrary-shift common unitary core."""
    n=len(C); Q=max(C); M=d*Q
    assert len(set(C))==n and d>1 and all(gcd(d,c)==1 for c in C)
    good=[C[i] for i in good_indices]
    assert all(gcd(a,b)==1 for a,b in combinations(good,2))
    bad=[C[i] for i in range(n) if i not in good_indices]
    I=range(shift+1,shift+1+M)
    K=[b//d for b in I if b%d==0]
    assert len(K)==Q and Q>=n
    chosen=set()
    for c in good:
        chosen.add(next(v for v in K if v%c==0))
    for v in K:
        if len(chosen)==n:break
        chosen.add(v)
    assert len(chosen)==n
    F={d*v for v in chosen}
    target=prime_power_levels([d*c for c in C])
    needs={}
    for (p,q),value in target.items():
        missing=max(0,value-sum(b%q==0 for b in F))
        needs[p]=max(needs.get(p,0),missing)
    def omega(x):
        c=0;p=2
        while p*p<=x:
            if x%p==0:
                c+=1
                while x%p==0:x//=p
            p+=1
        return c+int(x>1)
    budget=n+sum(omega(a) for a in bad)
    assert n+sum(needs.values())<=budget
    B=set(F)
    for p,m in needs.items():
        def val(b):
            v=0
            while b%p==0 and b:
                b//=p;v+=1
            return v
        candidates=sorted((b for b in I if b not in F),key=val,reverse=True)
        B.update(candidates[:m])
    assert len(B)<=budget and covers([d*c for c in C],B)
    return len(B),budget

def min_H_milp(A,shift,return_chosen=False):
    import numpy as np
    from scipy.optimize import milp, LinearConstraint, Bounds
    M=max(A)
    I=range(shift+1,shift+M+1)
    targets=prime_power_levels(A)
    qs=[q for _,q in targets]
    mat=np.array([[float(b%q==0) for b in I] for q in qs])
    sol=milp(c=np.ones(M),integrality=np.ones(M),bounds=Bounds(0,1),constraints=LinearConstraint(mat,np.array(list(targets.values())),np.inf),options={"time_limit":5.0})
    if sol.x is None or sol.status!=0:
        raise RuntimeError(f"MILP did not certify status {sol.status}")
    chosen=[b for b,x in zip(I,sol.x) if x>0.5]
    assert covers(A,chosen)
    return chosen if return_chosen else len(chosen)

def common_divisor_compression_milp(d,C,shift):
    n=len(C);Q=max(C);M=d*Q
    assert len(set(C))==n and d>1 and Q>=n
    I=range(shift+1,shift+1+M)
    K=[b//d for b in I if b%d==0]
    assert len(K)==Q and K==list(range(K[0],K[0]+Q))
    Kcover=min_H_milp(C,K[0]-1,return_chosen=True)
    F=set(Kcover)
    for v in K:
        if len(F)>=n:break
        F.add(v)
    B={d*v for v in F}
    assert len(B)==max(n,len(Kcover))
    A=[d*c for c in C]
    assert covers(A,B)
    return len(B),len(Kcover)

def prime_connected_component_bound(A):
    n=len(A)
    parent=list(range(n))
    def find(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]];i=parent[i]
        return i
    for i in range(n):
        for j in range(i):
            if gcd(A[i],A[j])>1:
                parent[find(i)]=find(j)
    groups={}
    for i,a in enumerate(A):
        groups.setdefault(find(i),[]).append(a)
    cost=0
    for group in groups.values():
        d=group[0]
        for v in group[1:]:d=gcd(d,v)
        assert max(group)%d==0
        cost+=max(group)//d
    return cost,len(groups)

def check_progression_multiset_lemma(rng,trials=500):
    """Check every arithmetic and path-counting inequality in the indexed-AP lemma."""
    checked=0; antecedent=0
    for _ in range(trials):
        H=rng.randrange(24,100)
        L=rng.choice([4,6,8])
        m=rng.randrange(3,14)
        steps=[rng.randrange(1,(H-1)//(L-1)+1) for _ in range(m)]
        rows=[]
        for d in steps:
            a=rng.randrange(1,H-(L-1)*d+1)
            rows.append([a+j*d for j in range(L)])
        U=set(v for r in rows for v in r)
        deg=Counter(v for r in rows for parity in [0,1] for v in r[parity::2])
        T=(L//2-1)*sum(v*(v-1) for v in deg.values())
        kap=max(sum(t%d==0 for d in steps) for t in range(1,H+1))
        sumsq=0
        for d in steps:
            residue=Counter(u%d for u in U)
            sumsq+=sum(c*c for c in residue.values())
        assert T<=2**0.5*kap*sumsq+1e-8
        if len(U)<=m:
            antecedent+=1
            assert L**3<16.001*kap**2*m
        checked+=1
    return checked,antecedent

def check_adversarial_progressions():
    """Explicit path-counting tests with |union|<=number of indexed rows."""
    samples=[([2]*6,4),([2]*20,6),([2]*7+[4]*7,4),
             ([3]*9+[6]*9,6),([5]*12+[10]*12,6),([2]*50,8)]
    for steps,L in samples:
        H=200
        rows=[[100+j*d for j in range(L)] for d in steps]
        U=set(v for r in rows for v in r)
        m=len(rows)
        assert len(U)<=m,(len(U),m)
        kap=max(sum(t%d==0 for d in steps) for t in range(1,H+1))
        deg=Counter(v for r in rows for parity in [0,1] for v in r[parity::2])
        T=(L//2-1)*sum(v*(v-1) for v in deg.values())
        sq=sum(sum(v*v for v in Counter(u%d for u in U).values()) for d in steps)
        assert T>=3*m*L**3/16
        assert T<=2**0.5*kap*sq+1e-8
        assert L**3<16*kap**2*m
    return len(samples)

def matching_with_one_forbidden(A,shift,forbidden):
    """Bipartite exact matching for simple lists of multiples (not exact profiles)."""
    M=max(A)
    labels=[]
    for a in A:
        atoms=[];x=a;p=2
        while p*p<=x:
            q=1
            while x%p==0:x//=p;q*=p
            if q>1:atoms.append(q)
            p+=1
        if x>1:atoms.append(x)
        blocks=[1,1]
        for q in sorted(atoms,reverse=True):
            idx=0 if blocks[0]<=blocks[1] else 1
            blocks[idx]*=q
        # explicit distinct-prime count
        for h in blocks:
            v=h;pf=0;p=2
            while p*p<=v:
                if v%p==0:
                    pf+=1
                    while v%p==0:v//=p
                p+=1
            if v>1:pf+=1
            if pf>=2:labels.append(h)
    labels=labels[:]
    L=2*(int(M**(1/3))//2)
    if L<4:return False
    kap=max(sum(t%h==0 for h in labels) for t in range(1,M+1)) if labels else 0
    if labels and not L**3>16*kap**2*len(labels):
        return False
    graph=[]
    for h in labels:
        first=shift+1+(-shift-1)%h
        v=[first+h*i for i in range(L)]
        assert v[-1]<=shift+M
        graph.append([b for b in v if b!=forbidden])
    owner={}
    def dfs(i,seen):
        for b in graph[i]:
            if b in seen:continue
            seen.add(b)
            if b not in owner or dfs(owner[b],seen):
                owner[b]=i
                return True
        return False
    assert all(dfs(i,set()) for i in range(len(labels)))
    return True

def main():
    summary={'seed':SEED,'pair_product_families':[], 'common_core_forced':[], 'common_core_random_checks':0, 'common_core_milp_checks':0,'graph_formula_checks':0,'stable_core_random_checks':0,'stable_core_max_slack':0,'compression_milp_checks':0,'compression_strict_improvements':0,'component_milp_checks':0,'component_bound_favorable':0,'progression_multiset_path_tests':0,'progression_rare_antecedents':0,'progression_adversarial_antecedents':0,'progression_matching_checks':0}
    for pp in ([101,103,107,109],[101,103,107,109,113],[101,103,107,109,113,127,131,137,139]):
        summary['pair_product_families'].append(pair_product_family(pp))
    for d in [6,30,210]:
        summary['common_core_forced'].append(forced_common_core_family(d,[101,103,107,109,113]))
    rng=Random(SEED)
    candidate_primes=[2,3,5,7,11,13,17,19,23,29]
    for _ in range(160):
        d=rng.choice([2,4,6,8,9,10,12,30])
        candidates=[p for p in candidate_primes if gcd(d,p)==1]
        if len(candidates)<2:continue
        C=rng.sample(candidates,rng.randrange(2,min(6,len(candidates))+1))
        shift=rng.choice([0,31,909, 10**17+13, 10**33-11])
        common_core_construct(d,C,shift)
        summary['common_core_random_checks']+=1
    for _ in range(160):
        d=rng.choice([2,4,6,9,10,30])
        pool=[p for p in candidate_primes if gcd(d,p)==1]
        if len(pool)<3:continue
        good=rng.sample(pool,rng.randrange(1, min(5,len(pool))+1))
        bad_pool=[v for v in range(2,120) if gcd(v,d)==1 and v not in good]
        bad=rng.sample(bad_pool,rng.randrange(0,4))
        C=good+bad
        if len(set(C))<len(C):continue
        rng.shuffle(C)
        ids={C.index(g) for g in good}
        sz,budget=stable_core_construct(d,C,ids,rng.choice([0,151,10**18+7]))
        summary['stable_core_random_checks']+=1
        summary['stable_core_max_slack']=max(summary['stable_core_max_slack'],budget-sz)
    # Actual exact integer MILP checks for multiple source families, no reliance on source code
    for d,C,shift in [(2,[3,5,7],0),(6,[5,7,11],137),(2,[3,5,7],10**7+7),(3,[2,5,7,11],999),(6,[7,11,13],10**8+19)]:
        A=[d*c for c in C]
        exact=min_H_milp(A,shift)
        assert exact==len(A), (A,shift,exact)
        summary['common_core_milp_checks']+=1
    for _ in range(80):
        Q=rng.randrange(5,24)
        n=rng.randrange(2,min(Q,8))
        C=rng.sample(range(1,Q),n-1)+[Q]
        d=rng.choice([2,3,4,6,9,10])
        shift=rng.choice([0,47,10**9+19])
        bound, hC=common_divisor_compression_milp(d,C,shift)
        summary['compression_milp_checks']+=1
        if bound<2*n:summary['compression_strict_improvements']+=1
    for _ in range(80):
        M=rng.randrange(9,43)
        n=rng.randrange(2,min(8,M))
        A=rng.sample(range(2,M),n-1)+[M]
        shift=rng.choice([0,31,10**9+17])
        bound,components=prime_connected_component_bound(A)
        actual=min_H_milp(A,shift)
        assert actual<=bound,(A,shift,actual,bound)
        summary['component_milp_checks']+=1
        if bound<=2*n:summary['component_bound_favorable']+=1
    c,a=check_progression_multiset_lemma(rng,800)
    summary['progression_multiset_path_tests']=c
    summary['progression_rare_antecedents']=a
    summary['progression_adversarial_antecedents']=check_adversarial_progressions()
    # Compare the explicit AP threshold to exact Hall matching for actual greedy blocks.
    for _ in range(120):
        M=5000
        A=rng.sample(range(800,M),5)
        A[-1]=M
        if len(set(A))<5: continue
        shift=rng.choice([0,31,10**11+73])
        if matching_with_one_forbidden(A,shift,shift+1+(-shift-1)%M):
            summary['progression_matching_checks']+=1
    # Prove via exhaustive graph incidence enumeration up to 5 labels x 4 primes:
    # R=beta-c+1; this independently checks the accounting formula.
    base_primes=[2,3,5,7]
    prime_sets=[set(s) for j in range(1,5) for s in combinations(base_primes,j)]
    from itertools import product
    for s in range(1,5):
        for groups in product(prime_sets,repeat=s):
            labels=[prod(v) for v in groups]
            nodes=list(range(s))+[s+i for i in range(4)]
            parent=list(range(s+4))
            def find(x):
                while parent[x]!=x:
                    parent[x]=parent[parent[x]];x=parent[x]
                return x
            def union(x,y):
                x=find(x);y=find(y)
                if x!=y:parent[x]=y
            E=0
            used=set(range(s))
            for i,g in enumerate(groups):
                for p in g:
                    j=s+base_primes.index(p)
                    used.add(j);E+=1;union(i,j)
            V=len(used)
            c=len({find(v) for v in used})
            beta=E-V+c
            assert graph_surplus(labels)==beta-c+1
            summary['graph_formula_checks']+=1
    out=Path(__file__).with_name('results.json')
    out.write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
