# Continuation of Erdős #708 research — 2026-11-26

Contents:
- `REPORT.md`: full Russian mathematical report, with the indexed-progression lemma and proofs, new large-M structural theorem, common-divisor compression and infinite families illustrating graph-cycle limitations.
- `verify.py`: reproducible independent Python verification, arithmetic examples, graph identity enumeration, exact MILP checks and path-counting tests.
- `results.json`: deterministic output of `python3 verify.py` using seed 708261126.

Run `python3 verify.py`; Python 3.10+ and `numpy`, `scipy` are required for exact finite MILP checks. No external web access is used. **The universal asymptotic conjecture remains open.**

Original research files are untouched. The result is a standalone continuation; literature priority and Lean validation are not established.
