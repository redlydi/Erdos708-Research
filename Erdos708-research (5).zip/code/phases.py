"""Exhaust the first extra p-adic digit; compare coordinatewise minimal profiles."""
from itertools import product
from math import lcm, prod
import json

def primes(M):
    return [p for p in range(2,M+1) if all(p%d for d in range(2,p))]

def check(M):
    ps = primes(M)
    L = lcm(*range(1,M+1))
    rad = prod(ps)
    count = 0
    for r in range(L):
        grids = []
        slots = []
        for p in ps:
            q = p
            while q*p <= M:
                q *= p
            slots.append(q*p)
            marks = [i for i in range(1,M+1) if (r+i)%q == 0]
            grids.append(marks if len(marks)==p else [0])
        predicted = set(product(*grids))
        seen = set()
        for t in range(rad):
            x = r+t*L
            profile = tuple(next((i for i in range(1,M+1) if (x+i)%h == 0),0)
                            for h in slots)
            seen.add(profile)
        minimal = {v for v in seen if not any(
            w!=v and all(a==0 or a==b for a,b in zip(w,v)) for w in seen)}
        assert minimal == predicted
        assert all(sum(a!=0 for a in v) <= M.bit_length()-1 for v in minimal)
        count += len(minimal)
    return dict(phases=L, lifts=L*rad, minimal_profiles=count)

if __name__ == '__main__':
    print(json.dumps({M:check(M) for M in range(2,7)}, indent=2))
