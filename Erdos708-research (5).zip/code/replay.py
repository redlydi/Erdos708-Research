"""Replay the pinned upstream sources in scratch space. See the report for dependencies."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[3]
REV = 'c7afd23d917eee1206e71ea076f499b02fbb90e2'


def digest(content):
    return hashlib.sha256(content).hexdigest()


def main():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args])
    entries = git('ls-tree', '-r', '--name-only', REV).decode().splitlines()
    inputs = {name: git('show', f'{REV}:{name}') for name in entries}
    summary = {'revision': REV, 'files': {k: digest(v) for k, v in inputs.items()},
               'archives': {}, 'runs': {}}
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        runs = []
        for name, content in inputs.items():
            path = tmp / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
            if name.endswith('.zip'):
                dest = path.with_suffix('')
                with zipfile.ZipFile(path) as z:
                    members = {}
                    for info in z.infolist():
                        member = (dest / info.filename).resolve()
                        assert member.is_relative_to(dest)
                        member.parent.mkdir(parents=True, exist_ok=True)
                        data = z.read(info)
                        member.write_bytes(data)
                        members[info.filename] = digest(data)
                        if member.suffix == '.py':
                            runs.append(member)
                    summary['archives'][name] = members
                    if (dest / 'SHA256.json').is_file():
                        expected = json.loads((dest / 'SHA256.json').read_bytes())
                        assert all(members[k] == v for k, v in expected.items())
            if name.startswith('reports/'):
                for idx, code in enumerate(re.findall(r'^```python\n(.*?)^```', content.decode(),
                                                      re.MULTILINE | re.DOTALL)):
                    script = path.with_name(path.stem + f'.{idx}.py')
                    script.write_text(code)
                    runs.append(script)
            if name.startswith('code/') and name.endswith('.py'):
                runs.append(path)
        for path in sorted(runs):
            ref = None
            if path.parent == tmp / 'code':
                ref = tmp / 'verification' / (path.stem + '_output.txt')
            elif path.name == 'verify.py':
                ref = path.parent / 'results.json'
            elif path.name == 'verify_robust_gluing.py':
                ref = path.parents[1] / 'verification/robust_results.json'
            elif path.name.startswith('erdos708_audit_'):
                ref = next(path.parent.glob('*.json'))
            original = ref.read_bytes() if ref else None
            result = subprocess.run([sys.executable, str(path)], cwd=path.parent,
                                    check=True, capture_output=True)
            run = {'stdout': result.stdout.decode().strip(), 'exit': result.returncode}
            if original is not None:
                if ref.suffix == '.json':
                    same = json.loads(original) == json.loads(result.stdout)
                else:
                    same = original.strip() == result.stdout.strip()
                run['recorded_output_matches'] = same
                assert same, path
            summary['runs'][str(path.relative_to(tmp))] = run
    print(json.dumps(summary, indent=2, ensure_ascii=False, sort_keys=True))


if __name__ == '__main__':
    main()
