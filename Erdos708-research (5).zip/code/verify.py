"""Exact finite checks for the interval-transfer argument. Python 3.10+, standard library."""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from math import gcd, lcm, prod
from random import Random
import json


@lru_cache(None)
def atoms(a):
    powers = []
    p = 2
    while p * p <= a:
        q = 1
        while a % p == 0:
            a //= p
            q *= p
        if q > 1:
            powers.append((p, q))
        p += 1
    if a > 1:
        powers.append((a, a))
    return powers


def split(a):
    blocks = [1, 1]
    for q in sorted((q for _, q in atoms(a)), reverse=True):
        i = 0 if blocks[0] <= blocks[1] else 1
        blocks[i] *= q
    return [h for h in blocks if h > 1]


def unitary_parts(h):
    ds = [1]
    for _, q in atoms(h):
        ds += [d * q for d in ds]
    return ds[1:]


def extract(source, W):
    parts = {a: split(a) for a in source}
    ds = sorted({d for bs in parts.values() for h in bs if len(atoms(h)) > 1
                 for d in unitary_parts(h)})
    groups = []
    regular = []
    for d in ds:
        group = [a for a in parts if a % d == 0 and gcd(d, a // d) == 1]
        if group and d * len(group) >= W:
            groups.append((d, [a // d for a in group]))
            regular.extend([d] * len(group))
            for a in group:
                del parts[a]
    for bs in parts.values():
        regular.extend(bs)
    return groups, regular


def multiples(start, width, h):
    return range((start // h + 1) * h, start + width + 1, h)


def match(labels, start, width, forbidden=frozenset()):
    owner = {}

    def extend(i, seen):
        for b in multiples(start, width, labels[i]):
            if b in seen or b in forbidden:
                continue
            seen.add(b)
            if b not in owner or extend(owner[b], seen):
                owner[b] = i
                return True
        return False

    for i in range(len(labels)):
        extend(i, set())
    return owner


def levels(A):
    counts = Counter()
    for a in A:
        for p, power in atoms(a):
            q = p
            while q <= power:
                counts[p, q] += 1
                q *= p
    return counts


def repair(A, start, M, placed):
    counts = levels(A)
    fixed = frozenset(placed)
    result = set(fixed)
    budget = 0
    for p in sorted({p for p, _ in counts}):
        qs = sorted(q for prime, q in counts if prime == p)
        k = max([0] + [counts[p, q] - sum(b % q == 0 for b in fixed) for q in qs])
        budget += k
        selected = set()
        for q in reversed(qs):
            for b in multiples(start, M, q):
                if len(selected) >= k:
                    break
                if b not in fixed:
                    selected.add(b)
            if len(selected) == k:
                break
        result.update(selected)
    assert all(sum(b % q == 0 for b in result) >= v for (_, q), v in counts.items())
    assert len(result) <= len(fixed) + budget
    return result, budget


def route_batch(groups, start, width):
    # Shortest usable prefix at this shift. Monotonicity permits binary search.
    used = 0
    route = {}
    for _, cofactors in groups:
        labels = [h for h in cofactors if len(atoms(h)) >= 2]
        if not labels:
            continue
        left, right = 0, min(width - used, max(labels) * len(labels))
        origin = start + used
        if len(match(labels, origin, right)) != len(labels):
            return None
        while left < right:
            mid = (left + right) // 2
            if len(match(labels, origin, mid)) == len(labels):
                right = mid
            else:
                left = mid + 1
        chosen = match(labels, origin, left)
        assert not (route.keys() & chosen.keys())
        route.update({b: labels[i] for b, i in chosen.items()})
        used += left
    return used, route


def check_instance(A, shift, W, rng, stats):
    M = max(A)
    n = len(A)
    groups, regular = extract(A, W)
    supplements = [c for _, cs in groups for c in cs if c > 1]
    all_labels = regular + supplements
    assert prod(all_labels) == prod(A) and len(all_labels) <= 2 * n
    assert sum(Fraction(1, d) for d, _ in groups) <= Fraction(n, W)
    assert all(len(set(cs)) == len(cs) and W * (M // d) <= M * len(cs)
               for d, cs in groups)
    active = [h for h in regular if len(atoms(h)) >= 2]
    assignments = defaultdict(list)
    missed = []
    for h, count in Counter(active).items():
        pool = [b for b in multiples(shift, M, h) if gcd(h, b // h) == 1]
        assert count - len(pool) <= 2 ** len(atoms(h))
        chosen = rng.sample(pool, min(len(pool), count))
        for b in chosen:
            assignments[b].append(h)
        missed += [h] * (count - len(chosen))
    for h, k in combinations(active, 2):
        if gcd(h, k) > 1 and all(dict(atoms(h))[p] == dict(atoms(k))[p]
                                  for p in dict(atoms(h)).keys() & dict(atoms(k)).keys()):
            assert lcm(h, k) <= M
    fixed = set()
    for b, tasks in assignments.items():
        bad = {h for h, k in combinations(tasks, 2) if gcd(h, k) > 1}
        bad.update(k for h, k in combinations(tasks, 2) if gcd(h, k) > 1)
        missed.extend(bad)
        if set(tasks) - bad:
            fixed.add(b)
    stats['regular_dropped'] += len(missed)
    mixed = [h for h in supplements if len(atoms(h)) >= 2]
    if mixed:
        stats['with_mixed_supplements'] += 1
        stats['repeated_mixed_supplements_across_groups'] += int(len(set(mixed)) < len(mixed))
        # Build disjoint packages until the unallocated suffix cannot fit one.
        routes = []
        length = 0
        while length < M:
            batch = route_batch(groups, shift + length, M - length)
            if batch is None:
                break
            width, route = batch
            assert width > 0 and len(route) == len(mixed)
            routes.append(route)
            length += width
        if routes:
            stats['with_complete_package'] += 1
            stats['with_two_or_more_packages'] += int(len(routes) >= 2)
            best = min(routes, key=lambda r: len(fixed.intersection(r)))
            occupied = fixed.intersection(best)
            assert len(occupied) <= len(fixed) // len(routes)
            stats['supplements_dropped_on_occupied_points'] += len(occupied)
            missed.extend(best[b] for b in occupied)
            fixed.update(best)
        else:
            stats['without_complete_package'] += 1
            missed.extend(mixed)
    got, _ = repair(A, shift, M, fixed)
    limit = len(all_labels) + sum(len(atoms(h)) - 1 for h in missed)
    assert len(got) <= limit
    stats['instances'] += 1
    stats['with_multiple_extracted_groups'] += int(len(groups) > 1)


def exact_covers():
    tested = strict = 0
    witness = None
    for M in range(2, 8):
        period = lcm(*range(1, M + 1))
        for x in range(period):
            I = range(x + 1, x + M + 1)
            candidates = [(prod(B), B) for k in range(M + 1) for B in combinations(I, k)]
            for k in range(M - 1):
                for small in combinations(range(2, M), k):
                    A = small + (M,)
                    D = levels(A)
                    h = next(len(B) for _, B in candidates
                             if all(sum(b % q == 0 for b in B) >= count
                                    for (_, q), count in D.items()))
                    tau = next(len(B) for value, B in candidates if value % prod(A) == 0)
                    assert tau <= h <= min(M, 2 * len(A))
                    tested += 1
                    if tau < h:
                        strict += 1
                        if witness is None:
                            witness = dict(A=A, x=x, tau=tau, H=h)
    # H is periodic modulo period. Truncation of tau at that period is not asserted.
    return dict(instances=tested, strict=strict, first_strict=witness)


def table_windows(Q):
    # Exact minimum union of mixed cofactor lists on a fixed grid of intervals.
    assert Q % 2 == 1
    M = 2 * Q
    cs = [c for c in range(Q // 2 + 1, Q + 1) if c % 2]
    mixed = [c for c in cs if len(atoms(c)) >= 2]
    base = Q * Q
    blocks = Q // 2
    mask = bytearray(blocks * M)
    for c in mixed:
        off = (-base - 1) % c
        mask[off::c] = b'\x01' * len(range(off, len(mask), c))
    i = min(range(blocks), key=lambda j: mask.count(1, j * M, (j + 1) * M))
    start = base + i * M
    neighbors = mask.count(1, i * M, (i + 1) * M)
    matching = match(mixed, start, M)
    assert len(matching) <= neighbors
    odds = ((start // 2 + 1) | 1)
    seed = {2 * (odds + 2 * j) for j in range(len(cs))}
    assert min(seed) > start and max(seed) <= start + M
    cover, budget = repair([2 * c for c in cs], start, M, seed)
    assert budget <= len({p for c in cs for p, _ in atoms(c)})
    return dict(Q=Q, n=len(cs), mixed=len(mixed), shift=start, union=neighbors,
                matching=len(matching), constructed_H_upper=len(cover))



def dense_checks(rng):
    tested = 0
    for M in (50, 150, 350):
        period = lcm(*range(1, M + 1))
        for j in range(40):
            x = (rng.randrange(M * M) if j % 2 else period + rng.randrange(M))
            cuts = sorted(rng.sample(range(1, M), 4)) + [M]
            low = 0
            source, placed = set(), set()
            cost = 0
            for high in cuts:
                mod = rng.randint(2, 9)
                residues = set(rng.sample(range(mod), rng.randint(1, mod - 1)))
                if high == M:
                    residues.add(M % mod)
                source.update(a for a in range(low + 1, high + 1) if a % mod in residues)
                placed.update(b for b in range(x + low + 1, x + high + 1)
                              if b % mod in residues)
                cost += len(residues)
                low = high
            assert len(placed) <= len(source) + cost
            big = sum(any(p*p > M for p, _ in atoms(a)) for a in source)
            small_primes = sum(1 for v in range(2, M+1) if atoms(v) == [(v, v)]
                               and v*v <= M)
            cover, _ = repair(source, x, M, placed)
            assert len(cover) <= len(source) + big + cost*(1 + small_primes)
            tested += 1
    dual_checks = 0
    for M in range(3, 9):
        primes = [p for p in range(2, M+1) if atoms(p) == [(p, p)]]
        def exponent(b, p):
            e = 0
            while b % p == 0:
                b //= p
                e += 1
            return e
        for x in (0, 4, 37, lcm(*range(1, M+1))*10**20):
            vals = {b: [exponent(b, p) for p in primes]
                    for b in set(range(2,M+1)) | set(range(x+1,x+M+1))}
            for weights in product(range(3), repeat=len(primes)):
                scores = {b: sum(e*w for e,w in zip(exps, weights))
                          for b, exps in vals.items()}
                penalty = sum(max(0,scores[b]-2) for b in range(x+1,x+M+1))
                for n in range(1, M):
                    all_costs = [scores[M]+sum(scores[a] for a in C)-penalty
                                 for C in combinations(range(2,M),n-1)]
                    top = sorted((scores[a] for a in range(2,M)),reverse=True)[:n-1]
                    assert max(all_costs) == sum(top)+scores[M]-penalty
                    dual_checks += 1
    return dict(residue_families=tested, fixed_weights_top_n_identities=dual_checks)



def check_reserved_row():
    # Same sampled families and shifts as the upstream small-match experiment.
    # Reserving the maximum source fixes a unique representative in every interval.
    rng = Random(708)
    tested = nonempty = failures = max_deficit = 0
    witness = None
    for M in range(12, 101):
        for n in [min(M - 1, size) for size in (4, 7, 12, 20, 40)]:
            for _ in range(50):
                A = sorted(set(rng.sample(range(2, M + 1), n - 1) + [M]))
                if len(A) != n:
                    continue
                x = rng.choice((0, rng.randrange(M * M), lcm(*range(2, min(M, 12))) - M // 2))
                b0 = (x // M + 1) * M
                hs = [h for a in A if a != M for h in split(a) if len(atoms(h)) >= 2]
                result = match(hs, x, M, {b0})
                assert b0 not in result
                missing = len(hs) - len(result)
                tested += 1
                nonempty += bool(hs)
                if missing:
                    failures += 1
                    max_deficit = max(max_deficit, missing)
                    if witness is None:
                        witness = dict(A=A, x=x, reserved=b0, missing=missing)
                else:
                    cover, _ = repair(A, x, M, {b0, *result})
                    assert len(cover) <= 2 * n - 1
    return dict(tested=tested, with_mixed=nonempty, failures=failures,
                max_deficit=max_deficit, first_failure=witness)


def main():
    rng = Random(708433)
    stats = Counter()
    for M in (62, 150, 315, 462, 750, 1155):
        period = lcm(*range(1, M + 1))
        for j in range(36):
            bases = rng.sample([2, 3, 5, 6, 10, 14, 15, 21], 3)
            pool = [a for a in range(2, M) if any(a % d == 0 for d in bases)]
            A = sorted(rng.sample(pool, min(len(pool), rng.randint(5, 55))) + [M])
            x = [0, rng.randrange(M*M), period * (10**30 + 1) - M // 2][j % 3]
            check_instance(A, x, rng.choice([10, 20, 35, max(3, M // 6)]), rng, stats)
    print(json.dumps(dict(seed=708433, construction=dict(sorted(stats.items())),
                          exhaustive=exact_covers(), dense=dense_checks(rng),
                          reserved=check_reserved_row(),
                          table=[table_windows(q) for q in (101, 301, 1001, 2001)]),
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
